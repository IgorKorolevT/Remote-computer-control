import os
import platform
import uuid
from typing import Optional, Any
from dotenv import dotenv_values
from dotenv.main import StrPath
import logging



def get_uniq_pk_name():
    """Get uniq code which doesn't change with time"""
    return f"Computer-{uuid.getnode()}"


def get_pk_password():
    """Return password which doesn't change with time"""
    system_uuid = platform.machine() + platform.processor() + platform.system()
    return str(uuid.uuid5(uuid.NAMESPACE_OID, system_uuid))


class Config:
    """Config class"""
    config_path: Optional[StrPath] = None
    create_config_if_not_exist: bool = True
    defaults_config_name: str = ".env"
    address: str = "igorkorolevcourseproject.duckdns.org"
    _defaults_url: str = "wss://" + address
    defaults_api_url: str = fr"https://{address}/computer/api/v1/"
    _defaults_name_genfunc = get_uniq_pk_name
    _defaults_password_genfunc = get_pk_password
    defaults_config_attrs = {'NAME': _defaults_name_genfunc(), 'URL': _defaults_url,
                             'PASSWORD': _defaults_password_genfunc()}
    encoding: Optional[str] = "utf-8"
    logger_format: str = 'At %(asctime)s in %(name)s %(levelname)s: %(message)s'
    logger_path: Optional[StrPath] = "main.log"
    logger_level: int = logging.INFO
    __Config = None
    _is_set_logger: bool = False

    def __init__(self):
        if not Config._is_set_logger:
            self.set_logger()

        if Config.__Config is not None:
            raise TypeError("Config class is already created")
        logger = logging.getLogger(__name__ + ".Config.__init__")
        logger.debug(f"Loading dotenv values on path: {Config.config_path}")
        self.__config = dotenv_values(dotenv_path=Config.config_path,
                                      encoding=Config.encoding)
        if not self.__config and not Config.create_config_if_not_exist:
            raise FileExistsError("Config file doesn't exist. Please create it or change config_path.")
        elif not self.__config and Config.create_config_if_not_exist:
            logger.warning(f"Create config file with default values. Please create it or change config_path.")
            with open(os.path.join(os.path.curdir, Config.defaults_config_name), "x") as config_file:
                for name, value in Config.defaults_config_attrs.items():
                    config_file.write(f'{name}={value}\n')
                self.__config = Config.defaults_config_attrs.copy()
        logger.debug(f"Loaded dotenv values successful. {self.__config}")
        self.set_url()

    def __getitem__(self, item: Any):
        return self.__config[item]

    def set_url(self):
        """Add url way to computer"""
        logger = logging.getLogger(__name__ + ".Config.set_url")
        if self.__config.get('URL') is None:
            raise ValueError("URL must be set in env file")
        self.__config['URL'] = f"{self.__config.get('URL')}/ws/computer/"
        logger.info(f"Set url in config to {self.__config['URL']}")

    @staticmethod
    def get_config() -> "Config":
        """Get Config instance or create it if it doesn't exist"""
        if Config.__Config is None:
            Config.__Config = Config()
        return Config.__Config

    @staticmethod
    def set_logger():
        logging.basicConfig(filename=Config.logger_path, level=Config.logger_level, format=Config.logger_format)
        Config._is_set_logger = True
