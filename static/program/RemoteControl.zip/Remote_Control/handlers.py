import subprocess
from RemoteControl import handle_m, main
import logging
from RemoteControl.config import Config


@handle_m
def my_handler(data: dict):
    message = data["message"]
    res = subprocess.run(message, shell=True, capture_output=True, text=True)
    if res.returncode != 0:
        return res.stderr
    return res.stdout


if __name__ == '__main__':
    Config.logger_level=logging.NOTSET
    main()
