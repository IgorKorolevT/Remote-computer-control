import asyncio
import websockets
import json
import logging
import functools
import requests
from .config import Config
from typing import Callable


class AuthorizedFailed(BaseException):
    """Need to register new user"""


class HandlerMessage:
    __handler_m = dict()
    __logger = logging.getLogger(__name__ + ".HandlerMessage")

    @staticmethod
    def get(type_m: str):
        """Get func to handler"""
        try:
            return HandlerMessage.__handler_m[type_m]
        except KeyError:
            HandlerMessage.__logger.error(f"handler of type message {type_m} doesn't exist or registered")
            return lambda *arg, **kwarg: ...

    @staticmethod
    def set(type_m: str, func: Callable):
        """Add pair type and func to handler"""
        if not callable(func):
            raise TypeError("func must be callable")
        HandlerMessage.__handler_m[type_m] = func
        HandlerMessage.__logger.debug(f"handler of type message {type_m} registered")

    @property
    def all(self):
        """Get all keys"""
        return HandlerMessage.__handler_m.keys()


class TypeMessage:
    """Base types of message"""
    BASE = "base"


def register_computer(name: str, password: str) -> None:
    response = requests.post(Config.defaults_api_url, headers={"Content-Type": "application/json"},
                             json={"name": name, "password": password})
    response.raise_for_status()


async def websocket_client():
    logger = logging.getLogger(__name__)
    config = Config.get_config()

    async def base_handling_messages(m: str):
        data: dict = json.loads(m)
        logger.info(f"Received message: {data}")
        if data.get("type") is None:
            data["type"] = TypeMessage.BASE
        res = HandlerMessage.get(data["type"])(data)
        try:
            json_response = json.dumps({"message": res, "receiver": data["sender"]})
        except json.decoder.JSONDecodeError:
            logger.error(f"Json decode error. {res}")
        else:
            logger.info(f"Sending response: {json_response}")
            await ws.send(json_response)
            logger.debug("Message sent successfully")

    headers = {
        "name": config['NAME'],
        "password": config['PASSWORD'],
    }

    try:
        async with websockets.connect(config['URL'], additional_headers=headers, logger=logger) as ws:
            logger.debug("Connected to websocket")
            async for message in ws:
                logger.debug(f"Handling message: {message}")
                await base_handling_messages(message)
                logger.debug(f"End handling message: {message}")
    except websockets.exceptions.ConnectionClosedError as e:
        if e.rcvd.code == 4401:
            raise AuthorizedFailed({"name": headers['name'], "password": headers['password']})
        else:
            logger.error(f"WebSocket closed: {e}")
    except websockets.exceptions.InvalidStatus as e:
        logger.error(f"WebSocket error: {e}")
    except ConnectionRefusedError as e:
        logger.error(f"WebSocket refused: {e}. Maybe server is down?")
    except TimeoutError as e:
        logger.error(f"WebSocket timeout: {e}")


def handle_m(func, type_m: str = None):
    """Register your func to handle it"""
    logger = logging.getLogger(f"{__name__} in handle_m")

    if type_m is None:
        type_m = TypeMessage.BASE
    logger.debug(f"type_m is {type_m}")

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        func(*args, **kwargs)
        return func(*args, **kwargs)

    HandlerMessage.set(type_m, wrapper)
    logger.debug(HandlerMessage.all)
    return wrapper


def main():
    """Run the WebSocket client"""
    logger = logging.getLogger(__name__)

    try:
        asyncio.run(websocket_client())
    except AuthorizedFailed as e:
        register_computer(e.args[0]["name"], e.args[0]["password"])
        asyncio.run(websocket_client())
    except KeyboardInterrupt as e:
        logger.warning("Forced closure")
