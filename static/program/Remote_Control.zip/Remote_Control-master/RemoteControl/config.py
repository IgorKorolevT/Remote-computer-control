from typing import Optional, Any
from dotenv import dotenv_values
from dotenv.main import StrPath
import logging


class Config:
    """Config class"""
    dotenv_path: Optional[StrPath] = None
    encoding: Optional[str] = "utf-8"
    __Config = None
    is_set_logger: bool = False

    def __init__(self):
        if not Config.is_set_logger:
            set_logger()

        if Config.__Config is not None:
            raise TypeError("Config class is already created")
        logger = logging.getLogger(__name__+".Config.__init__")
        logger.debug(f"Loading dotenv values on path: {Config.dotenv_path}")
        self.__config = dotenv_values(dotenv_path=Config.dotenv_path,
                                      encoding=Config.encoding)
        logger.debug("Loaded dotenv values successful")
        Config.__Config = True
        self.set_url()

    def __getitem__(self, item: Any):
        return self.__config[item]

    def set_url(self):
        """Add url way to computer"""
        logger = logging.getLogger(__name__ + ".Config.set_url")
        if self.__config.get('URL') is None:
            raise ValueError("URL must be set in env file")
        self.__config['URL'] = f"{self.__config.get('URL')}/ws/computer/"
        logger.info(f"Set url in config to {self.__config['URL']}")

    @staticmethod
    def get_config() -> "Config":
        """Get Config instance or create it if it doesn't exist"""
        if Config.__Config is None:
            __Config = Config()
        return __Config


def set_logger(logger_format: str = 'At %(asctime)s in %(name)s %(levelname)s: %(message)s',
               logger_path: Optional[StrPath] = "main.log", logger_level: int = logging.INFO):
    logging.basicConfig(filename=logger_path, level=logger_level, format=logger_format)
    Config.is_set_logger = True
